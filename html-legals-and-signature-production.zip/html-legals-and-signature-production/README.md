# html-legals-and-signature
Some templates for GDPR legals pages (cookies, privacy, legals mentions) and some template for clients html email signature.
